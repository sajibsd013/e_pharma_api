from django.shortcuts import render
from .serializers import NurseSerializer, CareGiverSerializer, PhysiotherapistSerializer, PartnerSerializer, DoctorSerializer, DMF_DoctorSerializer
from rest_framework import viewsets, pagination
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from api.utils import send_sms
# Create your views here.


@api_view(['POST'])
def dmf_doctor(request):
    if request.method == 'POST':
        serializer = DMF_DoctorSerializer(data=request.data)
        mobile = request.data.get("mobile")
        if serializer.is_valid():
            # send sms to admin and user
            send_sms(mobile, "Registration Success, We will contact you soon")
            send_sms("+8801771147384",
                     f"{mobile} Registered as a DMF Doctor")
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
def doctor(request):
    if request.method == 'POST':
        serializer = DoctorSerializer(data=request.data)
        mobile = request.data.get("mobile")
        if serializer.is_valid():
            # send sms to admin and user
            send_sms(mobile, "Registration Success, We will contact you soon")
            send_sms("+8801771147384",
                     f"{mobile} Registered as a Doctor")
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
def partner(request):
    if request.method == 'POST':
        serializer = PartnerSerializer(data=request.data)
        mobile = request.data.get("mobile")

        if serializer.is_valid():
            # send sms to admin and user
            send_sms(mobile, "Registration Success, We will contact you soon")
            send_sms("+8801771147384",
                     f"{mobile} Registered as a Partner")
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
def care_giver(request):
    if request.method == 'POST':
        serializer = CareGiverSerializer(data=request.data)
        mobile = request.data.get("mobile")

        if serializer.is_valid():
            # send sms to admin and user
            send_sms(mobile, "Registration Success, We will contact you soon")
            send_sms("+8801771147384",
                     f"{mobile} Registered as a caregiver ")
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
def physiotherapist(request):
    if request.method == 'POST':
        serializer = PhysiotherapistSerializer(data=request.data)
        mobile = request.data.get("mobile")

        if serializer.is_valid():
            # send sms to admin and user
            send_sms(mobile, "Registration Success, We will contact you soon")
            send_sms("+8801771147384",
                     f"{mobile} Registered as a physiotherapist")
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
def nurse_regi(request):
    if request.method == 'POST':
        serializer = NurseSerializer(data=request.data)
        mobile = request.data.get("mobile")

        if serializer.is_valid():
            # send sms to admin and user
            send_sms(mobile, "Registration Success, We will contact you soon")
            send_sms("+8801771147384",
                     f"{mobile} Registered as a nurse/brother")
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
