from django.urls import path, include
from rest_framework import routers
from rest_framework.urlpatterns import format_suffix_patterns
from partners import views

# Wire up our API using automatic URL routing.
# Additionally, we include login URLs for the browsable API.
urlpatterns = [
    path('nurse-regi/', views.nurse_regi),
    path('caregiver-regi/', views.care_giver),
    path('physiotherapist-regi/', views.physiotherapist),
    path('partner-regi/', views.partner),
    path('doctor-regi/', views.doctor),
    path('dmf-doctor-regi/', views.dmf_doctor),
]
