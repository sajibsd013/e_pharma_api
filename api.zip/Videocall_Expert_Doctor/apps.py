from django.apps import AppConfig


class VideocallExpertDoctorConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Videocall_Expert_Doctor'
